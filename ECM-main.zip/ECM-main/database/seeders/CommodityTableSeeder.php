<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CommodityTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('commodities')->insert([
            [
                'name'              => json_encode(['en' => 'cars'  , 'ar' => 'سيارات' ] , JSON_UNESCAPED_UNICODE) ,
                'created_at'        => Carbon::now()
            ],[
                'name'              => json_encode(['en' => 'Homes'  , 'ar' => 'منازل'] , JSON_UNESCAPED_UNICODE) ,
                'created_at'        => Carbon::now()
            ],[
                'name'              => json_encode(['en' => 'furniture'  , 'ar' => 'اثاث'] , JSON_UNESCAPED_UNICODE) ,
                'created_at'        => Carbon::now()
            ],[
                'name'              => json_encode(['en' => 'electronics'  , 'ar' => 'الكترونيات'] , JSON_UNESCAPED_UNICODE) ,
                'created_at'        => Carbon::now()
            ],[
                'name'              => json_encode(['en' => 'antiques'  , 'ar' => 'انتيكات'] , JSON_UNESCAPED_UNICODE) ,
                'created_at'        => Carbon::now()
            ]
        ]);
    }
}
