<?php

namespace Database\Seeders;

use App\Models\User;
use Carbon\Carbon;
use Faker\Factory as Faker;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        $faker_ar = Faker::create('ar_JO');

        $products = [];
        $list = [];
        for ($i = 0; $i < 100; $i++) {
            $products [] = [
                'name' => json_encode(['ar' => $faker_ar->name, 'en' => $faker->name] , JSON_UNESCAPED_UNICODE),

                'image' => 'default.png' ,
                'category_id' => rand(1,20) ,

                'price' => rand(20,50) ,

                'remarks' => json_encode(['ar' => $faker_ar->name, 'en' => $faker->name] , JSON_UNESCAPED_UNICODE),
                'created_at'     => $faker->dateTimeBetween($startDate = '-3 month',$endDate = 'now +6 month') ,
            ];

            $list [] = [
                'product_id'     => rand(1,99) ,
                'user_id'     => User::where('id' , rand(50,99))->first()->id ,
                'category_id'       =>  rand(1,20) ,

                'price' => rand(20,100) ,
                'unit' => 'kg',
                'created_at'     => $faker->dateTimeBetween($startDate = '-2 month',$endDate = 'now +4 month') ,


            ] ;

        }



        DB::table('products')->insert($products);
        DB::table('price_lists')->insert($list);
    }
}
