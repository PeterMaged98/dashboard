<?php

namespace App\Traits;

trait MenuTrait {
  public function home() {

    $menu = [
      [
        'name'  => __('admin.admins'),
        'count' => \App\Models\Admin::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/admins'),
      ],
        [
        'name'  => __('admin.users'),
        'count' => \App\Models\User::where('type' , 'user')->count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/clients'),
      ],

        [
            'name'  => __('admin.vendors'),
            'count' => \App\Models\User::where('type' , 'company')->count(),
            'icon'  => 'icon-users',
            'url'   => url('admin/clients'),
        ],

       [
        'name'  => __('site.category'),
        'count' => \App\Models\Category::count(),
        'icon'  => 'icon-list',
        'url'   => url('admin/categories'),
      ], [
        'name'  => __("admin.product"),
        'count' => \App\Models\Product::count(),
        'icon'  => 'icon-list',
        'url'   => url('admin/products'),
      ], [
        'name'  => __('admin.pricelist'),
        'count' => \App\Models\PriceList::count(),
        'icon'  => 'icon-list',
        'url'   => url('admin/pricelist'),
      ], [
        'name'  => __('admin.commodities'),
        'count' => \App\Models\Commodity::count(),
        'icon'  => 'icon-list',
        'url'   => url('admin/commodities'),
      ], [
        'name'  => __('admin.Validities'),
        'count' => \App\Models\Role::count(),
        'icon'  => 'icon-eye',
        'url'   => url('admin/roles'),
      ],
    ];

    return $menu;
  }

  public function introSiteCards() {
    $menu = [
      [
        'name'  => __('admin.insolder'),
        'count' => \App\Models\IntroSlider::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introsliders'),
      ],
      [
        'name'  => __('admin.Service_Suite'),
        'count' => \App\Models\IntroService::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introservices'),
      ],
      [
        'name'  => __('admin.questions_sections'),
        'count' => \App\Models\IntroFqsCategory::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introfqscategories'),
      ],
      [
        'name'  => __('admin.common_questions'),
        'count' => \App\Models\IntroFqs::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introfqs'),
      ],
      [
        'name'  => __('admin.Success_Partners'),
        'count' => \App\Models\IntroPartener::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introparteners'),
      ],
      [
        'name'  => __('admin.Customer_messages'),
        'count' => \App\Models\IntroMessages::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/intromessages'),
      ],
      [
        'name'  => __('admin.socials'),
        'count' => \App\Models\IntroSocial::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introsocials'),
      ],
      [
        'name'  => __('admin.how_the_site_works_section'),
        'count' => \App\Models\IntroHowWork::count(),
        'icon'  => 'icon-users',
        'url'   => url('admin/introhowworks'),
      ],
    ];
    return $menu;
  }

}