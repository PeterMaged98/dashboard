<?php

namespace App\Models;


class Image extends BaseModel
{
    const IMAGEPATH = 'images' ; 
    protected $fillable = ['image'];
}
