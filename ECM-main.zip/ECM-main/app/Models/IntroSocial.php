<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IntroSocial extends BaseModel
{
    protected $fillable = ['key','url','icon'];
}
