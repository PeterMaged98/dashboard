<?php

namespace App\Models;

use Spatie\Translatable\HasTranslations;

class PriceList extends BaseModel
{
    const IMAGEPATH = 'pricelists' ; 

    use HasTranslations; 
    protected $guarded = [];
    public $translatable = ['title','description'];


    public function company()
    {
        return $this->belongsTo(User::class , 'user_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class , 'product_id');
    }


    public function category()
    {
        return $this->belongsTo(Category::class);
    }

}
