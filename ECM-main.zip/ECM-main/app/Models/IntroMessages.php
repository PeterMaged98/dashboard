<?php

namespace App\Models;


class IntroMessages extends BaseModel
{
    protected $fillable = ['name','phone','email','message'];
}
