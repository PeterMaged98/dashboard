<?php

namespace App\Models;

use Spatie\Translatable\HasTranslations;

class Product extends BaseModel
{
    const IMAGEPATH = 'products' ; 

    use HasTranslations; 
    protected $fillable = ['name','category_id'  , 'price'   , 'remarks' , 'image'];
    public $translatable = ['name','remarks'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }


    public function vendors()
    {
        return $this->hasMany(PriceList::class);
    }


}
