<?php

namespace App\Models;

class Permission extends BaseModel
{
    protected $guarded = ['id'];

}
