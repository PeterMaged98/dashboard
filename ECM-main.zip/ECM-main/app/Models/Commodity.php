<?php

namespace App\Models;

use Spatie\Translatable\HasTranslations;

class Commodity extends BaseModel
{
    const IMAGEPATH = 'commodities' ; 

    use HasTranslations; 
    protected $fillable = ['name'];
    public $translatable = ['name'];


    public function users()
    {
        return $this->hasMany(User::class)->where('type' , '=' , 'company');
    }

}
