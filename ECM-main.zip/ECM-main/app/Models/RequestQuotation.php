<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestQuotation extends Model
{
    use HasFactory;


    protected $fillable = ['category_id' , 'product_id' , 'vendor_id','user_id' ,'quantity' , 'comments' , 'price' , 'unit'];


    public function vendor()
    {
        return $this->belongsTo(User::class , 'vendor_id')->where('type' , '==' , 'company');
    }


    public function user()
    {
        return $this->belongsTo(User::class , 'user_id')->where('type' , '==' , 'user');
    }
}

