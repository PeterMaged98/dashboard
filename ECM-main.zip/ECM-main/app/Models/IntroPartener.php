<?php

namespace App\Models;

class IntroPartener extends BaseModel
{
    protected $fillable = ['image'];
    const IMAGEPATH = 'parteners' ; 
}
