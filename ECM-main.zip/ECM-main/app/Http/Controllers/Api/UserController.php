<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Traits\ResponseTrait;

class UserController extends Controller {
  use ResponseTrait;

  /**
   * add user logic services like user home screen ...etc
   */

}
