<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Traits\ResponseTrait;

class CartController extends Controller {
  use ResponseTrait;

  /**
   * add cart services here
   */

}
