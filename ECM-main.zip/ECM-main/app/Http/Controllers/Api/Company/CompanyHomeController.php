<?php

namespace App\Http\Controllers\Api\Company;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Company\AddPriceListRequest;
use App\Http\Resources\Api\Company\HomeResource;
use App\Http\Resources\Api\Company\PriceListSingleResource;
use App\Http\Resources\Api\PriceListResource;
use App\Models\PriceList;
use Illuminate\Http\Request;

class CompanyHomeController extends Controller
{

    public function home()
    {
        $data = auth()->user()->priceList ;

        return $this->successData(HomeResource::collection($data));
    }


    public function addPriceList(AddPriceListRequest $request)
    {
        $data = auth()->user()->priceList()->create($request->validated());
        return $this->successData("");
        
    }


    public function getPriceList($id){
        $priiceList = PriceList::findOrFail($id);
        return $this->successData(new PriceListSingleResource($priiceList));
    }

    public function editPriceList($id , AddPriceListRequest $request)
    {
        $priiceList = PriceList::findOrFail($id);
        $priiceList->update($request->validated());
        return $this->successData(new PriceListResource($priiceList));

    }


    public function deletePriceList($id)
    {
        $priiceList = PriceList::findOrFail($id);
        $priiceList->delete();
        return $this->successData("");

    }
    //
}
