<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\products\Store;
use App\Http\Requests\Admin\products\Update;
use App\Models\Product ;
use App\Traits\ReportTrait;


class ProductController extends Controller
{
    public function index($id = null)
    {
        if (request()->ajax()) {
            $products = Product::search(request()->searchArray)->latest()->paginate(30);
            $html = view('admin.products.table' ,compact('products'))->render() ;
            return response()->json(['html' => $html]);
        }
        return view('admin.products.index');
    }

    public function create()
    {
        return view('admin.products.create');
    }


    public function store(Store $request)
    {
        Product::create($request->validated());
        ReportTrait::addToLog('  اضافه منتجات') ;
        return response()->json(['url' => route('admin.products.index')]);
    }
    public function edit($id)
    {
        $product = Product::findOrFail($id);
        return view('admin.products.edit' , ['product' => $product]);
    }

    public function update(Update $request, $id)
    {
        $product = Product::findOrFail($id)->update($request->validated());
        ReportTrait::addToLog('  تعديل منتجات') ;
        return response()->json(['url' => route('admin.products.index')]);
    }

    public function show($id)
    {
        $product = Product::findOrFail($id);
        return view('admin.products.show' , ['product' => $product]);
    }
    public function destroy($id)
    {
        $product = Product::findOrFail($id)->delete();
        ReportTrait::addToLog('  حذف منتجات') ;
        return response()->json(['id' =>$id]);
    }

    public function destroyAll(Request $request)
    {
        $requestIds = json_decode($request->data);
        
        foreach ($requestIds as $id) {
            $ids[] = $id->id;
        }
        if (Product::WhereIn('id',$ids)->get()->each->delete()) {
            ReportTrait::addToLog('  حذف العديد من منتج') ;
            return response()->json('success');
        } else {
            return response()->json('failed');
        }
    }
}
