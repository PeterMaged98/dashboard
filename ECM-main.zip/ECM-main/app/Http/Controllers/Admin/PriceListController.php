<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\pricelists\Store;
use App\Http\Requests\Admin\pricelists\Update;
use App\Models\PriceList ;
use App\Traits\ReportTrait;


class PriceListController extends Controller
{
    public function index($id = null)
    {
        if (request()->ajax()) {
            $pricelists = PriceList::search(request()->searchArray)->paginate(30);
            $html = view('admin.pricelists.table' ,compact('pricelists'))->render() ;
            return response()->json(['html' => $html]);
        }
        return view('admin.pricelists.index');
    }

    public function create()
    {
        return view('admin.pricelists.create');
    }


    public function store(Store $request)
    {
        PriceList::create($request->validated());
        ReportTrait::addToLog('  اضافه عرضالاسعار') ;
        return response()->json(['url' => route('admin.pricelists.index')]);
    }
    public function edit($id)
    {
        $pricelist = PriceList::findOrFail($id);
        return view('admin.pricelists.edit' , ['pricelist' => $pricelist]);
    }

    public function update(Update $request, $id)
    {
        $pricelist = PriceList::findOrFail($id)->update($request->validated());
        ReportTrait::addToLog('  تعديل عرضالاسعار') ;
        return response()->json(['url' => route('admin.pricelists.index')]);
    }

    public function show($id)
    {
        $pricelist = PriceList::findOrFail($id);
        return view('admin.pricelists.show' , ['pricelist' => $pricelist]);
    }
    public function destroy($id)
    {
        $pricelist = PriceList::findOrFail($id)->delete();
        ReportTrait::addToLog('  حذف عرضالاسعار') ;
        return response()->json(['id' =>$id]);
    }

    public function destroyAll(Request $request)
    {
        $requestIds = json_decode($request->data);
        
        foreach ($requestIds as $id) {
            $ids[] = $id->id;
        }
        if (PriceList::WhereIn('id',$ids)->get()->each->delete()) {
            ReportTrait::addToLog('  حذف العديد من عرضسعر') ;
            return response()->json('success');
        } else {
            return response()->json('failed');
        }
    }
}
