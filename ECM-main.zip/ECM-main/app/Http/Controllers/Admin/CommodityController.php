<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\commodities\Store;
use App\Http\Requests\Admin\commodities\Update;
use App\Models\Commodity ;
use App\Traits\ReportTrait;


class CommodityController extends Controller
{
    public function index($id = null)
    {
        if (request()->ajax()) {
            $commodities = Commodity::search(request()->searchArray)->paginate(30);
            $html = view('admin.commodities.table' ,compact('commodities'))->render() ;
            return response()->json(['html' => $html]);
        }
        return view('admin.commodities.index');
    }

    public function create()
    {
        return view('admin.commodities.create');
    }


    public function store(Store $request)
    {
        Commodity::create($request->validated());
        ReportTrait::addToLog('  اضافه سلع') ;
        return response()->json(['url' => route('admin.commodities.index')]);
    }
    public function edit($id)
    {
        $commodity = Commodity::findOrFail($id);
        return view('admin.commodities.edit' , ['commodity' => $commodity]);
    }

    public function update(Update $request, $id)
    {
        $commodity = Commodity::findOrFail($id)->update($request->validated());
        ReportTrait::addToLog('  تعديل سلع') ;
        return response()->json(['url' => route('admin.commodities.index')]);
    }

    public function show($id)
    {
        $commodity = Commodity::findOrFail($id);
        return view('admin.commodities.show' , ['commodity' => $commodity]);
    }
    public function destroy($id)
    {
        $commodity = Commodity::findOrFail($id)->delete();
        ReportTrait::addToLog('  حذف سلع') ;
        return response()->json(['id' =>$id]);
    }

    public function destroyAll(Request $request)
    {
        $requestIds = json_decode($request->data);
        
        foreach ($requestIds as $id) {
            $ids[] = $id->id;
        }
        if (Commodity::WhereIn('id',$ids)->get()->each->delete()) {
            ReportTrait::addToLog('  حذف العديد من سلعه') ;
            return response()->json('success');
        } else {
            return response()->json('failed');
        }
    }
}
