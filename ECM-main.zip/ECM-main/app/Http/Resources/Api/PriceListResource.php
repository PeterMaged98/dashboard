<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Resources\Json\JsonResource;

class PriceListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id ,
            'category_id'  => $this->category_id  ,
            'category_name'  => optional($this->category)->name  ,
            'product_name'  => optional($this->product)->name  ,
            'product_id'  => $this->product_id  ,
            'vendor_name'  => optional($this->company)->name  ,
            "vendor_id"    => $this->user_id ,
            "price" => $this->price  ,
            "unit" => $this->unit

        ];
    }
}
