<?php

namespace App\Http\Resources\Api\Company;

use App\Http\Resources\Api\Settings\CategoryResource;
use Illuminate\Http\Resources\Json\JsonResource;

class PriceListSingleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id ,
            'category'  => new CategoryResource($this->category) ,
            'product_id' => $this->product_id ,
            'product_name' => optional($this->product)->name ,
            'vendor_id'   => $this->user_id ,
            'vendor_name' => optional($this->company)->name ,

            'price' => $this->price ,
            'unit'  => $this->unit
        ];
    }
}
