<?php

namespace App\Http\Resources\API\Company;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class HomeProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id  ,
            'name' => $this->name ,
            'remarks' => $this->remarks ,
            'image' => $this->image ,
            'price' => $this->vendors->reverse()->first()->price ?? null ,
            'date' => Carbon::parse($this->vendors->reverse()->first()->created_at)->format('d//m//Y') ,
            'time'   =>  Carbon::parse($this->vendors->reverse()->first()->created_at)->format('g:i A') ,
        ];
    }
}
