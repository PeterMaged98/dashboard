<?php

namespace App\Http\Requests\API\RequestQuotation;

use App\Http\Requests\Api\BaseApiRequest;

use Illuminate\Foundation\Http\FormRequest;

class StoreRequest extends BaseApiRequest
{

    public function rules()
    {
        return [
          'category_id' => 'required|exists:categories,id' ,
//          'category_id' => 'required|exists:categories,id' ,
          'product_id' => 'required|exists:products,id' ,
          'vendor_id' => 'required' ,
          'quantity' => 'required' ,
          'price' => 'required' ,
          'unit' => 'required' ,
          'comments' => 'sometimes|required'
        ];
    }
}
