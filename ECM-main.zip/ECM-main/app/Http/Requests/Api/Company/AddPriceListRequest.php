<?php

namespace App\Http\Requests\Api\Company;

use App\Http\Requests\Api\BaseApiRequest;
use Illuminate\Foundation\Http\FormRequest;

class AddPriceListRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
           'category_id'  => 'required|exists:categories,id' ,
            'product_id'  => 'required|exists:products,id' ,
            'price' => 'required' ,
            'unit' => 'required'
        ];
    }
}
