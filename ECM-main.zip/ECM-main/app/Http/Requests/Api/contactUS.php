<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class contactUS extends BaseApiRequest
{



    public function rules()
    {
        return [
            'name' => 'required' ,
            'phone' => 'required' ,
            'email' => 'required' ,
            'messages' => 'required' ,
        ];
    }
}
